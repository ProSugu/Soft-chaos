export const environment = {
  production: true,
  logger: {
    level: 'TRACE',
  },
};
