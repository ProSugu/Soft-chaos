export const EMPTY_BANNER_TEXT_MODAL = {
    "heading": "",
    "desc": ""
};