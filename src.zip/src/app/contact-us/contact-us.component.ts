import {
  AfterViewInit,
  Component,
  ElementRef,
  OnInit,
  ViewChild,
} from '@angular/core';
import { environment } from 'src/environments/environment';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { } from 'googlemaps';
import { MapStyle } from './mapstyles';
import { Title } from '@angular/platform-browser';
import { HttpService } from '../utils/services/http/http.service';
import { Api } from '../utils/apis';
import { MessagingService } from '../utils/services/messaging/messaging.service';
@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.scss'],
})
export class ContactUsComponent implements  AfterViewInit {
  @ViewChild('map') mapElement!: ElementRef<HTMLInputElement>;
  map!: google.maps.Map;
  mapLoad: boolean = true;
  mapStyle: any = MapStyle;
  contactForm!: FormGroup;
  constructor(
    private titleService:Title,
    private fb: FormBuilder,
    private httpService: HttpService,
    private messagingService: MessagingService
  ) {
    this.contactForm = this.fb.group({
      Name: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      subject: ['', [Validators.required]],
      message: ['', [Validators.required]],
    });
  }
  ngAfterViewInit(): void {
    this.addMapsScript();
    this.titleService.setTitle("soft chaos-Contact")
  }
  loadMap() {
    var marker: any;
    const mapProperties = {
      center: new google.maps.LatLng(25.172541, 55.244054),
      zoom: 17,
      zoomControl:false,
      mapTypeControl:false,
      scrollwheel: false,
      streetViewControl: false,
      fullscreenControl: false,
      mapTypeId: google.maps.MapTypeId.ROADMAP,
    };
    var contentString =
    '<div id="content" style="margin:10px 10px 10px 5px;line-height: 1;overflow: hidden;white-space: nowrap;height:60px;margin:10px"><h3 style="font-weight:800">Soft Choas</h3><p>Al Fahidi - Bur Dubai - Office 43</p></div>';
    this.map = new google.maps.Map(
      this.mapElement.nativeElement,
      mapProperties
    );
    marker = new google.maps.Marker({
      map: this.map,
      icon: '/assets/images/drone.png',
      animation: google.maps.Animation.BOUNCE,
      position: mapProperties.center,
    });
    this.map.setOptions({ styles: this.mapStyle['silver'] });
    this.addInfoWindow(this.map, marker, contentString);
    this.mapLoad = false;
  }
  addInfoWindow(map: any, marker: any, message: any) {
    var infoWindow = new google.maps.InfoWindow({
      content: message,
    });

    google.maps.event.addListener(marker, 'click', function () {
      infoWindow.open(map, marker);
    });
  }
  submit() {
    // this.recaptchaV3Service.execute('importantAction')
    // .subscribe((token) => this.handleToken(token));
    // this.recaptchaService.execute({ action: 'submit' }).then((token) => {
    //   console.log(token);
    // });

    if(this.contactForm.valid) {
      this.httpService.postData(Api.contact,{data:{...this.contactForm.value}}).subscribe(res => {
        this.messagingService.toast('success',"Thanks, We will get back to you asap");
        this.contactForm.reset();
      })
    }
  }
  onCaptchaExpired(event: any) {
    console.log(event);
  }

  onCaptchaResponse(event: any) {
    console.log(event);
  }
  addMapsScript() {
    let googleMapsUrl = environment.googleMap.siteKey;
    if (!document.querySelectorAll(`[src="${googleMapsUrl}"]`).length) {
      document.body.appendChild(
        Object.assign(document.createElement('script'), {
          type: 'text/javascript',
          src: googleMapsUrl,
          onload: () => this.loadMap(),
        })
      );
    } else {
      this.loadMap();
    }
  }
}
