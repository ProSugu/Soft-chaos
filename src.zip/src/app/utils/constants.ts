export const constants = {

    imageType: ['image/jpg', 'image/jpeg', 'image/png'],
    PATTERNS: {
        email: /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
    }
};
