
export const api = 'api/';

export const Api = {
    contact:`${api}contact-uses`,
    carriers:`${api}carriers`,
    uploadFile:`${api}upload`,
    promoteYourServices:`${api}promote-your-services`,
};
